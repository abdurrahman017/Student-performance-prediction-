# Student Performance Prediction using Machine Learning

## Project overview
A supervised machine-learning mini project that estimates a student's expected final score from four academic indicators:
- Attendance percentage
- Previous marks
- Study hours per day
- Assignment completion percentage

The model used is **Linear Regression**. Evaluation uses Mean Absolute Error (MAE), Root Mean Squared Error (RMSE), and R-squared (R²).

## Important dataset note
The included `data/student_performance.csv` is a **synthetic, reproducible demonstration dataset** created for this project. It is not real student data and must not be represented as institutional or collected student records. For a research/production deployment, replace it with an authorized, appropriately anonymized real dataset and update the report's dataset description and results.

## Repository structure
```text
Student_Performance_Prediction_ML/
├── data/student_performance.csv
├── src/main.py
├── notebooks/student_performance_prediction.ipynb
├── models/                 # trained model created after running
├── outputs/                # metrics, predictions and plots created after running
├── Project_Report.docx
├── Presentation.pptx
├── requirements.txt
└── README.md
```

## Setup
Python 3.10 or later is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## Train and evaluate
Run from the project root:

```bash
python src/main.py --train
```

This splits the dataset into 80% training and 20% testing data, trains Linear Regression, calculates MAE/RMSE/R², and saves:
- `models/linear_regression_model.joblib`
- `outputs/evaluation_metrics.csv`
- `outputs/actual_vs_predicted.csv`
- `outputs/model_coefficients.csv`
- `outputs/actual_vs_predicted.png`
- `outputs/residual_plot.png`

## Predict an example student
First train the model, then run:

```bash
python src/main.py --predict --attendance 85 --previous-marks 72 --study-hours 3.5 --assignment 90
```

The output is an estimated score out of 100. The low-score message is only a support prompt, not a decision about a student.

## Workflow
1. Load and inspect the CSV dataset.
2. Separate input features (X) and target (y).
3. Split data into training and testing sets.
4. Train a Linear Regression model on the training set.
5. Predict scores for the test set.
6. Evaluate with MAE, RMSE and R².
7. Save the model, metrics and visualizations.

## Responsible use and limitations
Predictions are approximate and depend on the quality and representativeness of the data. Student outcomes can be influenced by factors not included here. Do not use this model to label, punish, rank, or deny opportunities to students. Use it only as one optional signal for supportive teacher review, with human judgement and student privacy safeguards.

## Team details
Update this section before submission with the actual team member names, roll numbers, and repository URL.
