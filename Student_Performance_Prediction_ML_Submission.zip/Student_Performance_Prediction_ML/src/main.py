"""Student Performance Prediction using Linear Regression."""
from pathlib import Path
import argparse
import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "student_performance.csv"
MODEL_PATH = ROOT / "models" / "linear_regression_model.joblib"
OUTPUT_DIR = ROOT / "outputs"
FEATURES = [
    "attendance_percentage",
    "previous_marks",
    "study_hours_per_day",
    "assignment_completion_percentage",
]
TARGET = "final_score"

def train():
    OUTPUT_DIR.mkdir(exist_ok=True)
    data = pd.read_csv(DATA_PATH)
    X, y = data[FEATURES], data[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    rmse = mean_squared_error(y_test, predictions) ** 0.5
    r2 = r2_score(y_test, predictions)
    metrics = pd.DataFrame([{
        "MAE": round(mae, 3), "RMSE": round(rmse, 3), "R2": round(r2, 3),
        "training_rows": len(X_train), "testing_rows": len(X_test)
    }])
    metrics.to_csv(OUTPUT_DIR / "evaluation_metrics.csv", index=False)

    comparison = pd.DataFrame({
        "actual_score": y_test.to_numpy(),
        "predicted_score": predictions.round(2)
    })
    comparison.to_csv(OUTPUT_DIR / "actual_vs_predicted.csv", index=False)

    plt.figure(figsize=(7, 5))
    plt.scatter(y_test, predictions, alpha=0.75)
    plt.xlabel("Actual final score")
    plt.ylabel("Predicted final score")
    plt.title("Actual vs Predicted Student Scores")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "actual_vs_predicted.png", dpi=160)
    plt.close()

    residuals = y_test.to_numpy() - predictions
    plt.figure(figsize=(7, 5))
    plt.scatter(predictions, residuals, alpha=0.75)
    plt.axhline(0, linestyle="--")
    plt.xlabel("Predicted final score")
    plt.ylabel("Residual (actual - predicted)")
    plt.title("Residual Plot")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "residual_plot.png", dpi=160)
    plt.close()

    coefficients = pd.DataFrame({
        "feature": FEATURES, "coefficient": model.coef_
    })
    coefficients.to_csv(OUTPUT_DIR / "model_coefficients.csv", index=False)
    joblib.dump(model, MODEL_PATH)

    print("Training completed.")
    print(metrics.to_string(index=False))
    print(f"Model saved to: {MODEL_PATH}")
    print(f"Evaluation files saved in: {OUTPUT_DIR}")

def predict(args):
    if not MODEL_PATH.exists():
        raise SystemExit("Model not found. Run: python src/main.py --train")
    model = joblib.load(MODEL_PATH)
    values = [[args.attendance, args.previous_marks, args.study_hours, args.assignment]]
    score = float(model.predict(pd.DataFrame(values, columns=FEATURES))[0])
    score = max(0.0, min(100.0, score))
    print(f"Estimated final score: {score:.2f}/100")
    if score < 40:
        print("Support indicator: consider checking in and offering academic support.")
    else:
        print("Support indicator: continue monitoring progress and providing feedback.")
    print("This is an estimate, not a grade or a substitute for teacher judgement.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Student Performance Prediction")
    parser.add_argument("--train", action="store_true", help="Train and evaluate model")
    parser.add_argument("--predict", action="store_true", help="Predict one student's score")
    parser.add_argument("--attendance", type=float, default=80)
    parser.add_argument("--previous-marks", dest="previous_marks", type=float, default=65)
    parser.add_argument("--study-hours", dest="study_hours", type=float, default=3)
    parser.add_argument("--assignment", type=float, default=75)
    args = parser.parse_args()
    if args.train or not args.predict:
        train()
    else:
        predict(args)
